❮ ❮ 𝐁𝐘 𝐏𝐀𝐓𝐎 ❯ ❯

➤Comandos

pkg update

pkg upgrade

pkg install git

git clone https://github.com/Mr-Pato/self-bot

cd self-bot

bash install.sh

npm start

➤Debes de tener 2 dispositivos para poder escanear 

➤Es self bot así que lo puedes usar en tu mismo número

➤Aplicacion utilizada - TERMUX

➤Para volverlo a activar usa 

cd self-bot
npm start

➤Para volverlo a activar en caso de cerrar wsp web o cambiar de número

cd self-bot
rm session.json
npm start y escaneas 
